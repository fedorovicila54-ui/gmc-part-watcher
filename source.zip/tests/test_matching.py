import unittest

from partwatch.matching import classify
from partwatch.models import Listing


class MatchingTests(unittest.TestCase):
    def listing(self, title="GMC Terrain II 2017-2022 молдинг крыла переднего левого", description="", **kwargs):
        return Listing(source="test", id=kwargs.pop("id", "42"), title=title,
                       url=kwargs.pop("url", "https://example.com/42"), description=description, **kwargs)

    def test_explicit_black_part_is_confirmed(self):
        item = self.listing(description="Молдинг переднего левого крыла черный.")
        self.assertEqual(classify(item, {}).status, "black")

    def test_english_black_fender_trim(self):
        item = self.listing(title="GMC Terrain 2019 black front left fender molding")
        self.assertEqual(classify(item, {}).status, "black")

    def test_explicit_part_colour_field(self):
        item = self.listing(description="Цвет детали: черный.")
        self.assertEqual(classify(item, {}).status, "black")
        item = self.listing(description="Цвет детали: черный, автомобиль белый.")
        self.assertEqual(classify(item, {}).status, "black")

    def test_donor_colour_does_not_confirm_trim(self):
        for description in ("Черный автомобиль, молдинг переднего левого крыла.",
                            "Машина черная. Молдинг переднего левого крыла.",
                            "Цвет кузова черный", "Цвет: черный"):
            with self.subTest(description=description):
                self.assertEqual(classify(self.listing(description=description), {}).status, "review")

    def test_absence_of_chrome_is_not_black(self):
        for description in ("Хром отсутствует.", "Не хром.", "Без хрома.",
                            "Молдинг не хромированный.", "Non-chrome molding."):
            with self.subTest(description=description):
                self.assertEqual(classify(self.listing(description=description), {}).status, "review")

    def test_chrome_listing_is_rejected_even_if_donor_is_black(self):
        item = self.listing(description="Черный автомобиль. Молдинг хромированный.")
        self.assertEqual(classify(item, {}).status, "reject")

    def test_black_part_with_negated_chrome_is_black(self):
        item = self.listing(description="Черный молдинг переднего левого крыла, не хром.")
        self.assertEqual(classify(item, {}).status, "black")

    def test_reference_id_is_excluded_in_both_id_and_url(self):
        for item in (self.listing(id="138518208"),
                     self.listing(url="https://parts.av.by/car/a_138518208")):
            self.assertEqual(classify(item, {}).status, "reject")

    def test_configured_exclusions(self):
        self.assertEqual(classify(self.listing(), {"excluded_ids": [42]}).status, "reject")

    def test_wrong_side_rear_part_model_and_generation(self):
        for title in ("GMC Terrain II 2019 молдинг переднего правого крыла черный",
                      "GMC Terrain II 2019 молдинг заднего левого крыла черный",
                      "GMC Acadia 2019 молдинг переднего левого крыла черный",
                      "GMC Terrain I 2014 молдинг переднего левого крыла черный",
                      "GMC Terrain 1 2017 молдинг переднего левого крыла черный",
                      "GMC Terrain III молдинг переднего левого крыла черный",
                      "GMC Terrain 3 молдинг переднего левого крыла черный",
                      "GMC Terrain 2025 молдинг переднего левого крыла черный"):
            with self.subTest(title=title):
                self.assertEqual(classify(self.listing(title=title), {}).status, "reject")

    def test_generic_black_trim_or_missing_side_is_rejected(self):
        for title in ("Черный молдинг", "GMC Terrain II черный молдинг порога",
                      "GMC Terrain II молдинг переднего крыла черный",
                      "GMC Terrain II левый руль молдинг переднего крыла черный"):
            with self.subTest(title=title):
                self.assertEqual(classify(self.listing(title=title), {}).status, "reject")

    def test_unknown_generation_requires_review_even_for_black_part(self):
        item = self.listing(title="GMC Terrain черный молдинг переднего левого крыла")
        self.assertEqual(classify(item, {}).status, "review")

    def test_unknown_finish_requires_review(self):
        self.assertEqual(classify(self.listing(), {}).status, "review")

    def test_verified_oem_number_requires_explicit_configuration(self):
        item = self.listing(description="OEM: 1234-5678")
        self.assertEqual(classify(item, {}).status, "review")
        self.assertEqual(classify(item, {"black_oem_numbers": ["12345678"]}).status, "black")
        self.assertEqual(classify(self.listing(description="OEM: 9123456789"),
                                  {"black_oem_numbers": ["12345678"]}).status, "review")

    def test_ambiguous_reference_oem_is_not_a_black_finish_proof(self):
        self.assertEqual(classify(self.listing(description="OEM 84107336"), {}).status, "review")

    def test_complete_arch_is_not_confirmed_as_the_separate_trim(self):
        for description in ("Черная накладка арки OEM 84579557.",
                            "Черный расширитель арки в сборе.",
                            "Whole black wheel arch molding assembly."):
            with self.subTest(description=description):
                self.assertEqual(classify(self.listing(description=description), {}).status, "review")

    def test_rear_trim_position_on_a_front_fender_is_not_a_rear_fender(self):
        item = self.listing(title="GMC Terrain II 2019 black front left fender upper rear molding")
        self.assertEqual(classify(item, {}).status, "black")
        item = self.listing(title="GMC Terrain II 2019 черный молдинг переднего левого крыла верхний задний")
        self.assertEqual(classify(item, {}).status, "black")

    def test_other_part_colour_rejected_but_donor_colour_ignored(self):
        self.assertEqual(classify(self.listing(description="Молдинг крыла белый"), {}).status, "reject")
        self.assertEqual(classify(self.listing(description="Автомобиль белый"), {}).status, "review")

    def test_listing_date_does_not_override_fitment(self):
        item = self.listing(description="Молдинг крыла черный. Объявление обновлено 2026-10-20.")
        self.assertEqual(classify(item, {}).status, "black")

    def test_notify_review_does_not_relabel_uncertain_listing(self):
        self.assertEqual(classify(self.listing(), {"notify_review": False}).status, "review")


if __name__ == "__main__":
    unittest.main()
