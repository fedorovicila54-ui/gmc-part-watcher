from pathlib import Path
import unittest

from partwatch.bamper import parse_bamper
from partwatch.http import FetchError

URL = "https://bamper.by/zchbu/zapchast_molding-kryla-perednego-levogo/marka_gmc/model_terrain/"


class BamperTests(unittest.TestCase):
    def test_live_cards_keep_description_price_and_oem_in_their_own_scope(self):
        html = (Path(__file__).parent / "fixtures" / "bamper-list.html").read_text(encoding="utf-8")
        items = parse_bamper(html, URL)
        self.assertEqual(len(items), 3)
        by_id = {item.id: item for item in items}
        first = by_id["10859-119342525"]
        self.assertEqual(first.price, "180 BYN")
        self.assertIn("84107336", first.description)
        self.assertIn("Мелкие царапинки", first.description)
        self.assertEqual(by_id["251341-144228579"].price, "60 BYN")
        self.assertNotIn("84107336", by_id["251341-144228579"].description)
        self.assertIn("под окраску", by_id["188866-108266664"].description)
        self.assertNotIn("под окраску", first.description)
        self.assertTrue(first.image_url.startswith("https://bamper.by/upload/"))

    def test_articul_ids_can_contain_hyphens_and_repeated_links_are_deduplicated(self):
        html = '''
          <a href="/zapchast_molding-kryla-perednego-levogo/415856-KLJ-GY-23/">
            Молдинг крыла переднего левого GMC Terrain 2017-2024
          </a>
          <a href="/zapchast_molding-kryla-perednego-levogo/415856-KLJ-GY-23/">
            Молдинг крыла переднего левого GMC Terrain 2017-2024
          </a>
        '''
        items = parse_bamper(html, URL)
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0].id, "415856-KLJ-GY-23")

    def test_challenge_and_unknown_markup_are_not_empty_results(self):
        for html in ("<title>Just a moment...</title>", "<html>New page layout</html>"):
            with self.subTest(html=html), self.assertRaises(FetchError):
                parse_bamper(html, URL)

    def test_only_public_detail_links_with_part_titles_are_candidates(self):
        # Synthetic test of the conservative fallback; real Bamper list HTML
        # was blocked and is not claimed as verified by this fixture.
        html = '''
          <a href="/zapchast_molding-kryla-perednego-levogo/254387-176952534_1/">
            Молдинг крыла переднего левого GMC Terrain 2
          </a>
          <a href="/zchbu/zapchast_molding-kryla-perednego-levogo/">Категория</a>
          <a href="https://outside.example/zapchast_molding-kryla/123-456/">Молдинг</a>
        '''
        items = parse_bamper(html, URL)
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0].id, "254387-176952534_1")
        self.assertEqual(items[0].description, "")
        self.assertNotIn("black", items[0].title.lower())


if __name__ == "__main__":
    unittest.main()
