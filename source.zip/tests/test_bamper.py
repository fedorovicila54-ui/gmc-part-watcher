import unittest

from partwatch.bamper import parse_bamper
from partwatch.http import FetchError

URL = "https://bamper.by/zchbu/zapchast_molding-kryla-perednego-levogo/marka_gmc/model_terrain/"


class BamperTests(unittest.TestCase):
    def test_challenge_and_unknown_markup_are_not_empty_results(self):
        for html in ("<title>Just a moment...</title>", "<html>New page layout</html>"):
            with self.subTest(html=html), self.assertRaises(FetchError):
                parse_bamper(html, URL)

    def test_only_public_detail_links_with_part_titles_are_candidates(self):
        # Synthetic test of the conservative fallback; real Bamper list HTML
        # was blocked and is not claimed as verified by this fixture.
        html = '''
          <a href="/zapchast_molding-kryla-perednego-levogo/254387-176952534_1/">
            Молдинг крыла переднего левого GMC Terrain 2
          </a>
          <a href="/zchbu/zapchast_molding-kryla-perednego-levogo/">Категория</a>
          <a href="https://outside.example/zapchast_molding-kryla/123-456/">Молдинг</a>
        '''
        items = parse_bamper(html, URL)
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0].id, "254387-176952534_1")
        self.assertEqual(items[0].description, "")
        self.assertNotIn("black", items[0].title.lower())


if __name__ == "__main__":
    unittest.main()
