import unittest
from unittest.mock import Mock, patch
from xml.etree import ElementTree

import requests

from partwatch.models import Decision, Listing
from partwatch.telegram import Telegram, TelegramError


class TelegramTests(unittest.TestCase):
    token = "12345:VERY_SECRET_TEST_TOKEN"

    def bot(self):
        return Telegram(self.token, "-123")

    def test_invalid_credentials_fail_without_echoing_secret(self):
        with self.assertRaises(TelegramError) as caught:
            Telegram("invalid-SENSITIVE-token", "123")
        self.assertNotIn("SENSITIVE", str(caught.exception))

    def test_chat_id_is_numeric_and_secret_whitespace_is_ignored(self):
        bot = Telegram(" " + self.token + "\n", " -123\n")
        self.assertEqual(bot.chat_id, "-123")
        self.assertEqual(bot.token, self.token)
        with self.assertRaisesRegex(TelegramError, "числовой"):
            Telegram(self.token, "@someone")

    def test_known_chat_not_found_error_has_safe_actionable_reason(self):
        response = Mock(status_code=400)
        response.json.return_value = {"ok": False, "error_code": 400, "description": "Bad Request: chat not found"}
        with patch("partwatch.telegram.requests.post", return_value=response):
            with self.assertRaisesRegex(TelegramError, "Start"):
                self.bot().send("test")

    def test_request_failure_does_not_expose_bot_url(self):
        with patch("partwatch.telegram.requests.post", side_effect=requests.ConnectionError(self.token)):
            with self.assertRaises(TelegramError) as caught:
                self.bot().send("test")
        self.assertNotIn(self.token, str(caught.exception))
        self.assertTrue(caught.exception.__suppress_context__)

    def test_api_error_does_not_echo_description_or_string_error_code(self):
        response = Mock(status_code=400)
        response.json.return_value = {"ok": False, "error_code": self.token, "description": self.token}
        with patch("partwatch.telegram.requests.post", return_value=response):
            with self.assertRaises(TelegramError) as caught:
                self.bot().send("test")
        self.assertNotIn(self.token, str(caught.exception))

    def test_invalid_json_and_non_object_json_are_controlled_errors(self):
        for value in (None, [], "unexpected"):
            response = Mock(status_code=200)
            response.json.return_value = value
            with self.subTest(value=value), patch("partwatch.telegram.requests.post", return_value=response):
                with self.assertRaises(TelegramError):
                    self.bot().send("test")
        response = Mock(status_code=200)
        response.json.side_effect = ValueError("malformed JSON " + self.token)
        with patch("partwatch.telegram.requests.post", return_value=response):
            with self.assertRaises(TelegramError) as caught:
                self.bot().send("test")
        self.assertNotIn(self.token, str(caught.exception))

    def test_non_boolean_ok_cannot_mark_notification_successful(self):
        response = Mock(status_code=200)
        response.json.return_value = {"ok": "false", "result": {"message_id": 1}}
        with patch("partwatch.telegram.requests.post", return_value=response):
            with self.assertRaises(TelegramError):
                self.bot().send("test")

    def test_successful_send_uses_configured_chat_without_live_delivery(self):
        response = Mock(status_code=200)
        response.json.return_value = {"ok": True, "result": {"message_id": 1}}
        with patch("partwatch.telegram.requests.post", return_value=response) as post:
            self.bot().send("hello")
        self.assertEqual(post.call_args.kwargs["json"]["chat_id"], "-123")
        self.assertEqual(post.call_args.kwargs["json"]["text"], "hello")
        self.assertEqual(post.call_args.kwargs["timeout"], 25)

    def test_listing_html_is_escaped_and_review_is_labelled_uncertain(self):
        listing = Listing("kufar", "1", '<script>"part"</script>',
                          'https://auto.kufar.by/item/1?a="x"&b=2', price="<100 BYN>")
        bot = self.bot()
        with patch.object(bot, "send") as send:
            bot.send_listing(listing, Decision("review", ["black <not confirmed>"]))
        message = send.call_args.args[0]
        self.assertNotIn("<script>", message)
        self.assertIn("&lt;script&gt;", message)
        self.assertIn("&quot;x&quot;&amp;b=2", message)
        self.assertIn("Кандидат", message)
        self.assertIn("&lt;not confirmed&gt;", message)

    def test_long_listing_title_does_not_cut_html_link_or_entity(self):
        response = Mock(status_code=200)
        response.json.return_value = {"ok": True, "result": {"message_id": 1}}
        listing = Listing("kufar", "1", "x" * 3900, "https://auto.kufar.by/item/1")
        with patch("partwatch.telegram.requests.post", return_value=response) as post:
            self.bot().send_listing(listing, Decision("review", ["Цвет требует проверки"]))
        message = post.call_args.kwargs["json"]["text"]
        self.assertLessEqual(len(message), 4096)
        ElementTree.fromstring("<root>" + message + "</root>")
        self.assertIn(listing.url, message)


if __name__ == "__main__":
    unittest.main()
