"""Synthetic contract tests; these fixtures are not captured AV.by markup."""

import unittest

from partwatch.avby import parse_avby, scrape
from partwatch.http import FetchError


BASE = "https://parts.av.by/car/gmc"
PATH = "/car/gmc_terrain_ii-2017-2022_molding-kryla-perednego-levogo_138518208"


class AvbyTests(unittest.TestCase):
    def test_scopes_description_price_and_image_to_single_card(self):
        html = f"""
        <html><body><header>Хром правая сторона 999 BYN</header><main>
          <article><a href="{PATH}">Молдинг крыла переднего левого GMC Terrain</a>
            <p>Черная деталь, все крепления целые</p><strong>120 BYN</strong>
            <img src="https://img.av.by/item.jpg" alt="Молдинг">
          </article>
          <article><a href="/car/gmc_terrain_molding_42">Правая хромированная</a>
            <p>Не подходящая деталь</p><strong>999 BYN</strong></article>
        </main></body></html>"""
        items = parse_avby(html, BASE)
        assert len(items) == 2
        assert items[0].id == "138518208"
        assert "Черная деталь" in items[0].description
        assert "Хром правая" not in items[0].description
        assert "Не подходящая" not in items[0].description
        assert items[0].price == "120 BYN"
        assert items[0].image_url == "https://img.av.by/item.jpg"


    def test_deduplicates_image_and_title_links_and_prefers_title_text(self):
        html = f"""<div class="listing-item">
          <a href="{PATH}?photo=1"><img alt="Фото" src="/photo.jpg"></a>
          <h3><a href="{PATH}#details">Молдинг переднего левого крыла</a></h3>
          <p>Черный</p></div>"""
        items = parse_avby(html, BASE)
        assert len(items) == 1
        assert items[0].title == "Молдинг переднего левого крыла"
        assert items[0].url == "https://parts.av.by" + PATH


    def test_uses_image_alt_or_slug_without_inventing_finish(self):
        html = f"""<div><a href="{PATH}"><img alt="Молдинг крыла"></a></div>
          <div><a href="/car/gmc_terrain_molding_42"></a></div>"""
        items = parse_avby(html, BASE)
        assert items[0].title == "Молдинг крыла"
        assert items[1].title == "gmc terrain molding"
        assert items[1].price == ""
        assert items[1].image_url == ""
        assert "черн" not in items[1].description


    def test_rejects_category_links_foreign_hosts_and_javascript(self):
        html = f"""<a href="/car/gmc">GMC</a>
          <a href="https://evil.example{PATH}">Чужой сайт</a>
          <a href="https://parts.av.by.evil.example{PATH}">Подмена домена</a>
          <a href="javascript:alert(1)">Нет</a>"""
        with self.assertRaises(FetchError):
            parse_avby(html, BASE)

    def test_distinguishes_explicit_empty_result_from_unknown_markup(self):
        assert parse_avby('<p>По вашему запросу ничего не найдено</p>', BASE) == []
        with self.assertRaises(FetchError):
            parse_avby('<main>Новая неизвестная разметка</main>', BASE)

    def test_price_does_not_include_adjacent_model_year(self):
        item = parse_avby(f'<article><a href="{PATH}">GMC Terrain 2022</a><b>120 BYN</b></article>', BASE)[0]
        assert item.price == '120 BYN'


    def test_uses_card_microdata_without_page_price(self):
        html = f"""<div itemprop="price" content="999"></div>
          <article><a title="Молдинг крыла" href="{PATH}"></a>
          <meta itemprop="price" content="75.50">
          <meta itemprop="priceCurrency" content="BYN"></article>"""
        item = parse_avby(html, BASE)[0]
        assert item.title == "Молдинг крыла"
        assert item.price == "75.50 BYN"


    def test_scrape_delegates_fetch_to_shared_client(self):
        class Client:
            def get(self, url):
                assert url == BASE
                return f'<article><a href="{PATH}">Молдинг</a></article>'

        assert len(scrape(Client(), BASE)) == 1
