from pathlib import Path
import json
import unittest
from unittest.mock import Mock

from partwatch.http import FetchError
from partwatch.kufar import _needs_detail, parse_kufar, scrape
from partwatch.models import Listing

FIXTURES = Path(__file__).parent / "fixtures"
LIST_URL = "https://auto.kufar.by/l/molding-kryla-perednego-levogo/z~gmc"
DETAIL_URL = "https://auto.kufar.by/vi/1086543965"


class KufarTests(unittest.TestCase):
    def test_live_listing_preserves_vehicle_and_minor_units(self):
        items = parse_kufar((FIXTURES / "kufar-list.html").read_text(encoding="utf-8"), LIST_URL)
        item = next(i for i in items if i.id == "1086543965")
        self.assertEqual(item.price, "90 BYN")
        self.assertIn("cars_model_v2", item.description)
        self.assertIn("Terrain", item.description)
        self.assertIn("84107336", item.description)
        generation = next(i for i in items if i.id == "1082999997")
        self.assertIn("cars_gen_v2", generation.description)
        self.assertIn("spares_regdate", generation.description)
        self.assertEqual(generation.price, "Договорная")

    def test_live_detail_reads_body_and_gallery(self):
        item = parse_kufar((FIXTURES / "kufar-detail.html").read_text(encoding="utf-8"), DETAIL_URL)[0]
        self.assertIn("царапины", item.description)
        self.assertEqual(item.price, "90 BYN")
        self.assertTrue(item.image_url.startswith("https://rms.kufar.by/v1/gallery/"))

    def test_detail_fetches_are_scoped_to_target_vehicle_and_part(self):
        listing_html = (FIXTURES / "kufar-list.html").read_text(encoding="utf-8")
        detail_html = (FIXTURES / "kufar-detail.html").read_text(encoding="utf-8")

        class Client:
            def __init__(self):
                self.calls = []

            def get(self, url):
                self.calls.append(url)
                if url == LIST_URL:
                    return listing_html
                if url == DETAIL_URL:
                    return detail_html
                raise FetchError("Fixture detail unavailable")

        client = Client()
        items = scrape(client, LIST_URL)
        self.assertIn("царапины", next(i for i in items if i.id == "1086543965").description)
        self.assertNotIn("https://auto.kufar.by/vi/1076498507", client.calls)  # Acadia
        self.assertNotIn("https://auto.kufar.by/vi/1076290349", client.calls)  # Terrain 3

    def test_changed_markup_is_failure_and_explicit_empty_is_empty(self):
        with self.assertRaises(FetchError):
            parse_kufar("<html><h1>Loading</h1></html>", LIST_URL)
        empty = '<script id="__NEXT_DATA__">{"props":{"initialState":{"listing":{"ads":[]}}}}</script>'
        self.assertEqual(parse_kufar(empty, LIST_URL), [])

    def test_new_corner_and_left_fender_names_are_eligible_for_details_without_front(self):
        for part in ("уголок зеркала левый", "треугольник левого зеркала",
                     "накладка у зеркала левая", "накладка возле левого зеркала",
                     "накладка крыла левого"):
            with self.subTest(part=part):
                item = Listing("kufar", "1", "GMC Terrain II 2019 " + part, DETAIL_URL)
                self.assertTrue(_needs_detail(item))

    def test_corner_detail_prefilter_still_excludes_unrelated_parts_and_mirror_assemblies(self):
        for title in ("GMC Acadia уголок зеркала левый",
                      "GMC Terrain III уголок зеркала левый",
                      "GMC Terrain II уголок зеркала правый",
                      "GMC Terrain II уголок двери левый",
                      "GMC Terrain II зеркало в сборе с левым уголком зеркала",
                      "GMC Terrain II накладка левого зеркала"):
            with self.subTest(title=title):
                self.assertFalse(_needs_detail(Listing("kufar", "1", title, DETAIL_URL)))

    def test_scrape_fetches_new_alias_details_and_preserves_uncertain_part_name(self):
        ads = [
            {"ad_id": 1, "ad_link": "https://auto.kufar.by/vi/1", "subject": "GMC Terrain II уголок зеркала левый"},
            {"ad_id": 2, "ad_link": "https://auto.kufar.by/vi/2", "subject": "GMC Terrain II накладка крыла левого"},
            {"ad_id": 3, "ad_link": "https://auto.kufar.by/vi/3", "subject": "GMC Terrain II зеркало в сборе с левым уголком зеркала"},
        ]

        def html(state):
            return '<script id="__NEXT_DATA__">' + json.dumps({"props": {"initialState": state}}) + "</script>"

        pages = {LIST_URL: html({"listing": {"ads": ads}})}
        for ad in ads[:2]:
            pages[ad["ad_link"]] = html({"adView": {"data": {"adId": ad["ad_id"], "adViewLink": ad["ad_link"],
                                                          "title": ad["subject"], "body": "Нужно сверить форму и крепления"}}})
        client = Mock()
        client.get.side_effect = lambda url: pages[url]
        items = scrape(client, LIST_URL)
        self.assertEqual([call.args[0] for call in client.get.call_args_list],
                         [LIST_URL, "https://auto.kufar.by/vi/1", "https://auto.kufar.by/vi/2"])
        self.assertIn("сверить форму", items[0].description)
        self.assertIn("уголок зеркала", items[0].title)


if __name__ == "__main__":
    unittest.main()
