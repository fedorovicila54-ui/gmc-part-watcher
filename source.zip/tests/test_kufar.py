from pathlib import Path
import unittest

from partwatch.http import FetchError
from partwatch.kufar import parse_kufar, scrape

FIXTURES = Path(__file__).parent / "fixtures"
LIST_URL = "https://auto.kufar.by/l/molding-kryla-perednego-levogo/z~gmc"
DETAIL_URL = "https://auto.kufar.by/vi/1086543965"


class KufarTests(unittest.TestCase):
    def test_live_listing_preserves_vehicle_and_minor_units(self):
        items = parse_kufar((FIXTURES / "kufar-list.html").read_text(encoding="utf-8"), LIST_URL)
        item = next(i for i in items if i.id == "1086543965")
        self.assertEqual(item.price, "90 BYN")
        self.assertIn("cars_model_v2", item.description)
        self.assertIn("Terrain", item.description)
        self.assertIn("84107336", item.description)
        generation = next(i for i in items if i.id == "1082999997")
        self.assertIn("cars_gen_v2", generation.description)
        self.assertIn("spares_regdate", generation.description)
        self.assertEqual(generation.price, "Договорная")

    def test_live_detail_reads_body_and_gallery(self):
        item = parse_kufar((FIXTURES / "kufar-detail.html").read_text(encoding="utf-8"), DETAIL_URL)[0]
        self.assertIn("царапины", item.description)
        self.assertEqual(item.price, "90 BYN")
        self.assertTrue(item.image_url.startswith("https://rms.kufar.by/v1/gallery/"))

    def test_detail_fetches_are_scoped_to_target_vehicle_and_part(self):
        listing_html = (FIXTURES / "kufar-list.html").read_text(encoding="utf-8")
        detail_html = (FIXTURES / "kufar-detail.html").read_text(encoding="utf-8")

        class Client:
            def __init__(self):
                self.calls = []

            def get(self, url):
                self.calls.append(url)
                if url == LIST_URL:
                    return listing_html
                if url == DETAIL_URL:
                    return detail_html
                raise FetchError("Fixture detail unavailable")

        client = Client()
        items = scrape(client, LIST_URL)
        self.assertIn("царапины", next(i for i in items if i.id == "1086543965").description)
        self.assertNotIn("https://auto.kufar.by/vi/1076498507", client.calls)  # Acadia
        self.assertNotIn("https://auto.kufar.by/vi/1076290349", client.calls)  # Terrain 3

    def test_changed_markup_is_failure_and_explicit_empty_is_empty(self):
        with self.assertRaises(FetchError):
            parse_kufar("<html><h1>Loading</h1></html>", LIST_URL)
        empty = '<script id="__NEXT_DATA__">{"props":{"initialState":{"listing":{"ads":[]}}}}</script>'
        self.assertEqual(parse_kufar(empty, LIST_URL), [])


if __name__ == "__main__":
    unittest.main()
