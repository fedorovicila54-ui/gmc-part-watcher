import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

from partwatch.__main__ import read_state, run
from partwatch.http import FetchError
from partwatch.models import Listing
from partwatch.telegram import TelegramError


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.state = Path(self.temp.name) / "state.json"
        self.report = Path(self.temp.name) / "report.json"
        self.config = {"sources": [{"name": "kufar", "url": "https://auto.kufar.by/test"}],
                       "notify_review": True, "max_notifications": 10}
        self.client = Mock()
        self.bot = Mock()

    @staticmethod
    def listing(identity="1", black=True):
        return Listing("kufar", identity,
                       "GMC Terrain II 2019 молдинг крыла переднего левого" + (" черный" if black else ""),
                       "https://auto.kufar.by/item/" + identity)

    def seed(self, sent=None, health=None):
        value = {"version": 1, "sent": sent or {}, "health": health if health is not None else {"kufar": "ok:"},
                 "last_run": "previous-run"}
        self.state.write_text(json.dumps(value), encoding="utf-8")
        return value

    def execute(self, listings=None, notify=True, error=None):
        with patch("partwatch.kufar.scrape", return_value=listings or [], side_effect=error), contextlib.redirect_stdout(io.StringIO()):
            return run(self.config, self.state, self.report, notify=notify, client=self.client, telegram=self.bot)

    def load_report(self):
        return json.loads(self.report.read_text(encoding="utf-8"))

    def test_dry_run_leaves_existing_state_byte_for_byte_unchanged(self):
        self.seed(sent={"kufar:old:black": "earlier"}, health={"kufar": "unavailable:old error"})
        original = self.state.read_bytes()
        self.assertEqual(self.execute([self.listing()], notify=False), 0)
        self.assertEqual(self.state.read_bytes(), original)
        self.bot.send.assert_not_called()
        self.bot.send_listing.assert_not_called()
        self.assertEqual(self.load_report()["sent"], 0)
        self.assertEqual(len(self.load_report()["candidates"]), 1)

    def test_dry_run_does_not_create_state(self):
        self.execute([self.listing()], notify=False)
        self.assertFalse(self.state.exists())

    def test_successful_listing_is_deduplicated_across_runs_and_within_page(self):
        self.seed()
        duplicate = self.listing()
        self.execute([duplicate, duplicate])
        self.execute([duplicate])
        self.assertEqual(self.bot.send_listing.call_count, 1)
        self.assertIn("kufar:1:black", read_state(self.state)["sent"])
        self.assertEqual(self.load_report()["sent"], 0)

    def test_review_upgraded_to_black_gets_one_new_notification(self):
        self.seed()
        self.execute([self.listing(black=False)])
        self.execute([self.listing(black=True)])
        self.execute([self.listing(black=True)])
        self.assertEqual(self.bot.send_listing.call_count, 2)
        self.assertEqual(set(read_state(self.state)["sent"]), {"kufar:1:review", "kufar:1:black"})

    def test_disabled_review_notification_is_not_marked_sent(self):
        self.seed()
        self.config["notify_review"] = False
        self.execute([self.listing(black=False)])
        self.bot.send_listing.assert_not_called()
        self.assertEqual(read_state(self.state)["sent"], {})
        self.assertEqual(self.load_report()["candidates"][0]["status"], "review")

    def test_cap_keeps_unsent_candidate_eligible_for_next_run(self):
        self.seed()
        self.config["max_notifications"] = 1
        self.execute([self.listing("1", black=False), self.listing("2", black=True)])
        self.assertEqual(self.bot.send_listing.call_args.args[0].id, "2")
        self.assertEqual(set(read_state(self.state)["sent"]), {"kufar:2:black"})
        self.execute([self.listing("1", black=False), self.listing("2", black=True)])
        self.assertEqual(set(read_state(self.state)["sent"]), {"kufar:1:review", "kufar:2:black"})

    def test_send_failure_preserves_prior_success_and_retries_unsent(self):
        self.seed(sent={"kufar:old:black": "earlier"})
        self.bot.send_listing.side_effect = [None, TelegramError("temporary send failure")]
        with self.assertRaises(TelegramError):
            self.execute([self.listing("1"), self.listing("2")])
        saved = read_state(self.state)["sent"]
        self.assertIn("kufar:old:black", saved)
        self.assertIn("kufar:1:black", saved)
        self.assertNotIn("kufar:2:black", saved)
        self.bot.send_listing.reset_mock(side_effect=True)
        self.execute([self.listing("1"), self.listing("2")])
        self.bot.send_listing.assert_called_once()
        self.assertEqual(self.bot.send_listing.call_args.args[0].id, "2")

    def test_health_is_sent_only_on_change_and_recovers_once(self):
        self.seed(health={})
        self.execute([])
        self.execute([])
        self.execute(error=FetchError("blocked: HTTP 403"))
        self.execute(error=FetchError("blocked: HTTP 403"))
        self.execute([])
        self.execute([])
        self.assertEqual(self.bot.send.call_count, 3)
        self.assertEqual(read_state(self.state)["health"]["kufar"], "ok:")

    def test_health_send_failure_does_not_mark_the_change_as_delivered(self):
        self.seed(health={"kufar": "ok:"})
        self.bot.send.side_effect = TelegramError("temporary failure")
        with self.assertRaises(TelegramError):
            self.execute(error=FetchError("robots forbidden"))
        self.assertEqual(read_state(self.state)["health"]["kufar"], "ok:")
        self.bot.send.reset_mock(side_effect=True)
        self.assertEqual(self.execute(error=FetchError("robots forbidden")), 2)
        self.bot.send.assert_called_once()

    def test_source_error_is_unavailable_not_false_zero_results(self):
        self.seed()
        self.assertEqual(self.execute(error=FetchError("blocked: HTTP 429")), 2)
        source = self.load_report()["sources"][0]
        self.assertEqual(source["status"], "unavailable")
        self.assertNotIn("count", source)
        self.assertIn("429", source["error"])

    def test_malformed_state_stops_before_scraping_or_notifications(self):
        for value in ("broken json", "[]", "null", '{"version":1,"sent":[],"health":{}}',
                      '{"version":2,"sent":{},"health":{}}'):
            with self.subTest(value=value):
                self.state.write_text(value, encoding="utf-8")
                with patch("partwatch.kufar.scrape") as scrape, self.assertRaises(ValueError):
                    run(self.config, self.state, self.report, notify=True, client=self.client, telegram=self.bot)
                scrape.assert_not_called()
        self.bot.send.assert_not_called()
        self.bot.send_listing.assert_not_called()


if __name__ == "__main__":
    unittest.main()
