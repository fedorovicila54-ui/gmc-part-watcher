from types import SimpleNamespace
import unittest
from unittest.mock import patch

import requests

from partwatch.http import Client, FetchError, check_response, validate_url


def response(status=200, text="ok", location=None):
    return SimpleNamespace(status_code=status, text=text, content=text.encode(),
                           is_redirect=location is not None, headers={"Location": location} if location else {},
                           apparent_encoding="utf-8", encoding=None)


class HttpTests(unittest.TestCase):
    def test_only_https_marketplace_urls_are_allowed(self):
        for url in ("http://bamper.by/test", "https://evil.test/test", "https://bamper.by.evil.test/test",
                    "https://user:password@bamper.by/test", "https://bamper.by:444/test",
                    "https://127.0.0.1/test"):
            with self.subTest(url=url), self.assertRaises(FetchError):
                validate_url(url)

    def test_malformed_port_is_a_controlled_fetch_error(self):
        with self.assertRaises(FetchError):
            validate_url("https://bamper.by:notaport/test")

    def test_kufar_query_urls_are_rejected_before_network_access(self):
        client = Client()
        with patch.object(client.session, "get") as get:
            with self.assertRaisesRegex(FetchError, "robots"):
                client.get("https://auto.kufar.by/test?query=terrain")
        get.assert_not_called()

    def test_blocked_responses_are_never_successful_empty_pages(self):
        for status, body in ((403, ""), (429, ""), (468, ""), (200, "<script>SafeLineChallenge</script>"),
                             (200, "<title>Just a moment</title>")):
            with self.subTest(status=status, body=body), self.assertRaises(FetchError):
                check_response(status, body)

    def test_robots_denial_prevents_page_request(self):
        client = Client()
        with patch.object(client, "_request", return_value=response(text="User-agent: *\nDisallow: /")) as request:
            with self.assertRaisesRegex(FetchError, "robots"):
                client.get("https://bamper.by/search")
        request.assert_called_once_with("https://bamper.by/robots.txt")

    def test_unavailable_or_html_robots_is_not_ignored(self):
        for robots in (response(503, "maintenance"), response(200, "<html>challenge</html>")):
            client = Client()
            with self.subTest(status=robots.status_code), patch.object(client, "_request", return_value=robots) as request:
                with self.assertRaises(FetchError):
                    client.get("https://bamper.by/search")
                self.assertEqual(request.call_count, 1)

    def test_missing_robots_allows_page_and_policy_is_cached(self):
        client = Client()
        with patch.object(client, "_request", side_effect=[response(404, ""), response(text="page one"), response(text="page two")]) as request:
            self.assertEqual(client.get("https://bamper.by/one"), "page one")
            self.assertEqual(client.get("https://bamper.by/two"), "page two")
        self.assertEqual(request.call_count, 3)

    def test_cross_site_redirect_is_rejected_before_contacting_target(self):
        client = Client()
        with patch.object(client.session, "get", return_value=response(302, "", "https://evil.test/steal")) as get, patch("partwatch.http.time.sleep"):
            with self.assertRaises(FetchError):
                client._request("https://bamper.by/search")
        self.assertEqual(get.call_count, 1)
        self.assertFalse(get.call_args.kwargs["allow_redirects"])

    def test_network_error_does_not_echo_exception_url_or_credentials(self):
        client = Client()
        with patch.object(client.session, "get", side_effect=requests.ConnectionError("SECRET-CREDENTIAL URL")), patch("partwatch.http.time.sleep"):
            with self.assertRaises(FetchError) as caught:
                client._request("https://bamper.by/search")
        self.assertNotIn("SECRET-CREDENTIAL", str(caught.exception))

    def test_robots_crawl_delay_is_passed_to_page_fetch(self):
        client = Client(interval=3)
        with patch.object(client, "_request", side_effect=[response(text="User-agent: *\nCrawl-delay: 20\nAllow: /"), response(text="page")]) as request:
            self.assertEqual(client.get("https://bamper.by/search"), "page")
        self.assertEqual(request.call_args.args[1], 20)


if __name__ == "__main__":
    unittest.main()
