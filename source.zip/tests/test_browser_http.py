"""Browser transport behavior with fake pages; never starts a real browser."""
from types import SimpleNamespace
import json
import os
import subprocess
import unittest
from unittest.mock import Mock, patch

from partwatch.browser_http import BrowserSession as BrowserTransport, BrowserTransport as IsolatedTransport
from partwatch.http import FetchError


class FakePage:
    def __init__(self, html="<html>Catalogue</html>", title="Каталог", status=200,
                 auto_finish=False, robots_text=None):
        self.html = html
        self.page_title = title
        self.status = status
        self.auto_finish = auto_finish
        self.robots_text = robots_text
        self.main_frame = object()
        self.url = "about:blank"
        self.handlers = {}
        self.waits = []
        self.closed = False

    def on(self, event, callback):
        self.handlers[event] = callback

    def route(self, pattern, callback):
        self.route_callback = callback

    def emit_document(self):
        self.handlers["response"](SimpleNamespace(
            request=SimpleNamespace(resource_type="document"),
            frame=self.main_frame, status=self.status,
        ))

    def goto(self, url, **kwargs):
        self.url = url
        self.emit_document()

    def content(self):
        return self.html

    def title(self):
        return self.page_title

    def wait_for_timeout(self, milliseconds):
        self.waits.append(milliseconds)
        if self.auto_finish:
            self.html = "<html><body>Actual catalogue</body></html>"
            self.page_title = "Каталог"
            self.status = 200
            self.emit_document()

    def locator(self, selector):
        if selector != "body":
            raise AssertionError("Only read-only body extraction is expected")
        return SimpleNamespace(inner_text=lambda **kwargs: self.robots_text)

    def close(self):
        self.closed = True


class BrowserHttpTests(unittest.TestCase):
    @staticmethod
    def transport(page):
        transport = BrowserTransport()
        transport.context = Mock()
        transport.context.new_page.return_value = page
        return transport

    def test_automatic_javascript_navigation_can_finish_without_clicking(self):
        page = FakePage("<script>SafeLineChallenge</script>", "Just a moment", 403, auto_finish=True)
        transport = self.transport(page)
        with patch("partwatch.browser_http.time.monotonic", side_effect=[0, 1]):
            result = transport.get("https://bamper.by/catalogue")
        self.assertEqual(result.status_code, 200)
        self.assertIn("Actual catalogue", result.text)
        self.assertEqual(page.waits, [1000])
        self.assertTrue(page.closed)
        self.assertEqual(transport.blocked, {})


    def test_unapproved_url_is_rejected_before_spawning(self):
        with patch("partwatch.browser_http.subprocess.Popen") as spawn:
            with self.assertRaises(FetchError):
                IsolatedTransport().get("https://evil.test/")
        spawn.assert_not_called()

    def test_worker_returns_html_without_receiving_telegram_secrets(self):
        process = Mock(returncode=0)
        process.communicate.return_value = (json.dumps({"status": 200, "text": "<html>cards</html>", "storage_state": {"cookies": []}}), "unused private stderr")
        with patch.dict(os.environ, {"TELEGRAM_BOT_TOKEN": "TEST_ONLY", "GITHUB_TOKEN": "TEST_ONLY"}), patch("partwatch.browser_http.subprocess.Popen", return_value=process) as spawn:
            transport = IsolatedTransport()
            result = transport.get("https://bamper.by/catalogue")
        self.assertEqual(result.text, "<html>cards</html>")
        self.assertNotIn("TELEGRAM_BOT_TOKEN", spawn.call_args.kwargs["env"])
        self.assertNotIn("GITHUB_TOKEN", spawn.call_args.kwargs["env"])
        transport.close()
        self.assertIsNone(transport.storage_state)

    def test_timeout_stops_only_owned_worker_and_caches_unavailable_host(self):
        process = Mock()
        process.communicate.side_effect = subprocess.TimeoutExpired("worker", 80)
        transport = IsolatedTransport()
        with patch("partwatch.browser_http.subprocess.Popen", return_value=process) as spawn, patch.object(transport, "_stop") as stop:
            with self.assertRaisesRegex(FetchError, "лимит"):
                transport.get("https://bamper.by/catalogue")
            stop.assert_called_once_with(process)
            with self.assertRaisesRegex(FetchError, "лимит"):
                transport.get("https://bamper.by/robots.txt")
            self.assertEqual(spawn.call_count, 1)

    def test_invalid_worker_output_does_not_echo_stderr(self):
        process = Mock(returncode=1)
        process.communicate.return_value = ("invalid json", "SECRET token and cookie")
        with patch("partwatch.browser_http.subprocess.Popen", return_value=process):
            with self.assertRaises(FetchError) as error:
                IsolatedTransport().get("https://bamper.by/catalogue")
        self.assertNotIn("SECRET", str(error.exception))

    def test_unresolved_human_check_remains_unavailable_and_is_cached_per_host(self):
        page = FakePage("<div class='slg-copyright'>Confirm You Are Human</div>", status=468)
        transport = self.transport(page)
        with patch("partwatch.browser_http.time.monotonic", side_effect=[0, 41]):
            with self.assertRaisesRegex(FetchError, "interactive"):
                transport.get("https://parts.av.by/car/gmc")
        self.assertTrue(page.closed)
        with self.assertRaisesRegex(FetchError, "interactive"):
            transport.get("https://parts.av.by/robots.txt")
        transport.context.new_page.assert_called_once()

    def test_robots_uses_rendered_plain_text_instead_of_browser_html_wrapper(self):
        page = FakePage("<html><body><pre>User-agent: *\nDisallow: /car</pre></body></html>",
                        robots_text="User-agent: *\nDisallow: /car")
        result = self.transport(page).get("https://parts.av.by/robots.txt")
        self.assertEqual(result.text, "User-agent: *\nDisallow: /car")
        self.assertNotIn("<html", result.text)
        self.assertTrue(page.closed)

    def test_document_navigation_outside_approved_hosts_is_aborted(self):
        page = FakePage()
        self.transport(page).get("https://bamper.by/catalogue")
        request = SimpleNamespace(url="https://evil.test/redirect", frame=page.main_frame,
                                  is_navigation_request=lambda: True)
        route = Mock(request=request)
        page.route_callback(route)
        route.abort.assert_called_once()
        route.continue_.assert_not_called()

    def test_transport_failure_closes_page_and_does_not_echo_private_exception(self):
        page = FakePage()
        page.goto = Mock(side_effect=RuntimeError("SECRET cookie data"))
        transport = self.transport(page)
        with self.assertRaises(FetchError) as caught:
            transport.get("https://bamper.by/catalogue")
        self.assertNotIn("SECRET", str(caught.exception))
        self.assertTrue(page.closed)
