"""Public pages only: robots.txt, small request rate, no challenge bypass."""
import time
from urllib.parse import urljoin, urlsplit
from urllib.robotparser import RobotFileParser

import requests


class FetchError(Exception):
    pass


ALLOWED_HOSTS = {"auto.kufar.by", "www.kufar.by", "kufar.by", "bamper.by", "www.bamper.by", "parts.av.by"}
BLOCK_MARKERS = ("safelinechallenge", "slg-copyright", "cf-chl-", "<title>just a moment", "система безопасности")


def validate_url(url):
    try:
        parts = urlsplit(url)
        port = parts.port
    except ValueError:
        raise FetchError("Некорректный URL") from None
    if parts.scheme != "https" or parts.hostname not in ALLOWED_HOSTS or parts.username or parts.password or port not in (None, 443):
        raise FetchError("URL вне разрешенных площадок")
    if parts.hostname.endswith("kufar.by") and parts.query:
        raise FetchError("robots: для Kufar используются только URL без query-параметров")


def check_response(status, body):
    if status in (401, 403, 429, 468) or any(x in body[:150000].lower() for x in BLOCK_MARKERS):
        raise FetchError(f"blocked: HTTP {status}, защита или ограничение запросов")
    if status >= 400:
        raise FetchError(f"HTTP {status}")


class Client:
    def __init__(self, interval=3, browser_hosts=None, browser_channel="chromium", browser_headless=True):
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "GMCPartWatcher/1.0", "Accept-Language": "ru,en;q=0.8"})
        self.interval = max(2, float(interval))
        self.robots = {}
        self.last_request = {}
        self.browser_hosts = set(browser_hosts or [])
        self.browser_channel = browser_channel
        self.browser_headless = browser_headless
        self.browser = None
        self.browser_used = set()

    def _fetch(self, url, interval=None):
        response = self._request(url) if interval is None else self._request(url, interval)
        host = urlsplit(url).hostname
        try:
            check_response(response.status_code, response.text)
        except FetchError:
            if response.status_code == 429 or host not in self.browser_hosts or not (response.status_code in (403, 468) or any(x in response.text[:150000].lower() for x in BLOCK_MARKERS)):
                return response
            if self.browser is None:
                from .browser_http import BrowserTransport
                self.browser = BrowserTransport(self.browser_channel, self.browser_headless)
            response = self.browser.get(url)
            self.browser_used.add(host)
        return response

    def close(self):
        if self.browser is not None:
            self.browser.close()
        self.session.close()

    def _request(self, url, interval=None):
        for _ in range(5):
            validate_url(url)
            host = urlsplit(url).hostname
            delay = (interval or self.interval) - (time.monotonic() - self.last_request.get(host, 0))
            if delay > 0:
                time.sleep(delay)
            try:
                response = self.session.get(url, timeout=(10, 25), allow_redirects=False)
            except requests.RequestException:
                raise FetchError("network: ошибка подключения или таймаут") from None
            finally:
                self.last_request[host] = time.monotonic()
            if response.is_redirect:
                url = urljoin(url, response.headers.get("Location", ""))
                continue
            response.encoding = response.apparent_encoding or "utf-8"
            if len(response.content) > 12_000_000:
                raise FetchError("Ответ превышает лимит 12 MB")
            return response
        raise FetchError("Слишком много перенаправлений")

    def get(self, url):
        validate_url(url)
        parts = urlsplit(url)
        origin = f"{parts.scheme}://{parts.netloc}"
        if origin not in self.robots:
            response = self._fetch(origin + "/robots.txt")
            robot = RobotFileParser()
            if response.status_code == 404:
                robot.parse([])
            else:
                check_response(response.status_code, response.text)
                if "<html" in response.text[:500].lower():
                    raise FetchError("robots.txt недоступен: получена HTML-страница")
                robot.parse(response.text.splitlines())
            self.robots[origin] = robot
        robot = self.robots[origin]
        if not robot.can_fetch("GMCPartWatcher", url):
            raise FetchError("robots: автоматическое чтение URL запрещено robots.txt")
        delay = max(self.interval, robot.crawl_delay("GMCPartWatcher") or 0)
        rate = robot.request_rate("GMCPartWatcher")
        if rate and rate.requests:
            delay = max(delay, rate.seconds / rate.requests)
        response = self._fetch(url, delay)
        check_response(response.status_code, response.text)
        return response.text
