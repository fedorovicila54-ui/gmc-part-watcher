"""Conservative AV.by HTML adapter.

The reference listing and search response were blocked during development
(HTTP 468 / SafeLine). These selectors are defensive fallbacks, not a claim
that a live AV.by search was successfully parsed. The shared HTTP client must
raise on challenge pages; an empty result is never evidence of availability.
"""

from __future__ import annotations

import re
from urllib.parse import unquote, urljoin, urlsplit, urlunsplit

from bs4 import BeautifulSoup, Tag

from .http import FetchError
from .models import Listing


_LISTING_PATH = re.compile(r"^/car/([^/]+)_(\d+)$", re.IGNORECASE)
_CARD_CLASS = re.compile(r"(?:^|[-_])(?:card|item|advert|offer)(?:$|[-_])", re.I)
_WRAPPER_CLASS = re.compile(r"(?:^|[-_])(?:container|results|grid|list)(?:$|[-_])", re.I)
_PRICE = re.compile(
    r"(?:\$\s*\d[\d\s\u00a0]*(?:[.,]\d{1,2})?|"
    r"\d[\d\s\u00a0]*(?:[.,]\d{1,2})?\s*(?:BYN|USD|бел\.?\s*руб\.?|руб\.?|р\.|\$))",
    re.IGNORECASE,
)
_GENERIC_LABELS = {"фото", "подробнее", "открыть", "смотреть", "изображение"}


def _clean(value: str | None) -> str:
    return " ".join((value or "").split())


def _listing_url(href: str, base_url: str) -> tuple[str, str] | None:
    parsed = urlsplit(urljoin(base_url, href))
    if (
        parsed.scheme not in {"http", "https"}
        or parsed.hostname != "parts.av.by"
        or parsed.username
        or parsed.password
    ):
        return None
    path = parsed.path.rstrip("/")
    match = _LISTING_PATH.fullmatch(path)
    if match is None:
        return None
    return urlunsplit(("https", "parts.av.by", path, "", "")), match.group(2)


def _card(anchor: Tag, listing_id: str, base_url: str) -> Tag:
    """Find one small card, never use the page as the listing description."""
    fallback: Tag | None = None
    for depth, parent in enumerate(anchor.parents):
        if not isinstance(parent, Tag) or depth >= 5:
            break
        if parent.name in {"html", "body", "main", "header", "footer", "nav", "[document]"}:
            break
        ids = {
            found[1]
            for link in parent.find_all("a", href=True)
            if (found := _listing_url(str(link["href"]), base_url)) is not None
        }
        if ids != {listing_id}:
            break
        if len(parent.get_text(" ", strip=True)) > 2400:
            break
        classes = parent.get("class", [])
        if parent.name in {"article", "li"} or any(_CARD_CLASS.search(name) for name in classes):
            return parent
        if fallback is None and parent.name == "div" and not any(_WRAPPER_CLASS.search(name) for name in classes):
            if not parent.find(["header", "footer", "nav", "main", "h1"]):
                fallback = parent
    return fallback or anchor


def _title(anchor: Tag, canonical_url: str) -> tuple[str, int]:
    for candidate, priority in (
        (anchor.get_text(" ", strip=True), 3),
        (str(anchor.get("title", "")), 2),
        (str(image.get("alt", "")) if (image := anchor.find("img")) else "", 1),
    ):
        candidate = _clean(candidate)
        if candidate and candidate.casefold() not in _GENERIC_LABELS:
            return candidate, priority
    # This is only text from the URL, not a translated or inferred part name.
    slug = unquote(urlsplit(canonical_url).path.rsplit("/", 1)[-1]).rsplit("_", 1)[0]
    return _clean(slug.replace("_", " ").replace("-", " ")), 0


def _image(card: Tag, base_url: str) -> str:
    for image in card.find_all("img"):
        for attribute in ("data-src", "data-original", "src"):
            source = image.get(attribute)
            if not isinstance(source, str) or not source.strip():
                continue
            parsed = urlsplit(urljoin(base_url, source))
            if parsed.scheme in {"https", "http"} and parsed.hostname:
                return parsed.geturl()
    return ""


def _price(card: Tag) -> str:
    microdata = card.find(attrs={"itemprop": "price"})
    if microdata is not None:
        amount = _clean(str(microdata.get("content", "")) or microdata.get_text(" ", strip=True))
        currency_tag = card.find(attrs={"itemprop": "priceCurrency"})
        currency = ""
        if currency_tag is not None:
            currency = _clean(str(currency_tag.get("content", "")) or currency_tag.get_text(" ", strip=True))
        if amount:
            return _clean(f"{amount} {currency}")
    # Do not concatenate the model year in the title with the next price node.
    for text in card.stripped_strings:
        match = _PRICE.search(text)
        if match:
            return _clean(match.group(0))
    return ""


def parse_avby(html: str, url: str) -> list[Listing]:
    """Parse observed listing links, keeping all optional fields card-scoped."""
    soup = BeautifulSoup(html, "html.parser")
    for element in soup(["script", "style", "noscript"]):
        element.decompose()
    found: dict[str, tuple[Listing, int]] = {}
    for anchor in soup.find_all("a", href=True):
        target = _listing_url(str(anchor["href"]), url)
        if target is None:
            continue
        canonical_url, listing_id = target
        title, priority = _title(anchor, canonical_url)
        card = _card(anchor, listing_id, url)
        listing = Listing(
            source="avby",
            id=listing_id,
            title=title,
            url=canonical_url,
            description=_clean(card.get_text(" ", strip=True))[:1800],
            price=_price(card),
            image_url=_image(card, url),
        )
        previous = found.get(listing_id)
        if previous is None or priority > previous[1]:
            found[listing_id] = listing, priority
    if found:
        return [listing for listing, _ in found.values()]
    if re.search(
        r"ничего не найдено|по вашему запросу[^<]{0,80}не найден|объявления не найдены",
        soup.get_text(" ", strip=True),
        re.I,
    ):
        return []
    raise FetchError("AV.by: unsupported markup; live listing HTML could not be verified")


def scrape(client, url: str) -> list[Listing]:
    """Fetch one public page; challenge detection belongs to the HTTP client."""
    return parse_avby(client.get(url), url)
