"""Conservative Bamper HTML link extraction, with explicit unsupported status.

Live automated access returned a Cloudflare challenge during verification.
The HTTP client must report that block; this module never attempts to bypass it.
"""
from __future__ import annotations

from html.parser import HTMLParser
import re
from urllib.parse import urljoin, urlparse

from .http import FetchError
from .models import Listing


class _Links(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.link = None
        self.links = []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag == "a":
            self.link = [values.get("href", ""), values.get("title", ""), []]
        elif tag == "img" and self.link is not None and values.get("alt"):
            self.link[2].append(values["alt"])

    def handle_data(self, data):
        if self.link is not None:
            self.link[2].append(data)

    def handle_endtag(self, tag):
        if tag == "a" and self.link is not None:
            self.links.append(self.link)
            self.link = None


def parse_bamper(html: str, url: str) -> list[Listing]:
    parser = _Links()
    parser.feed(html)
    items = {}
    for href, title_attr, parts in parser.links:
        link = urljoin(url, href)
        parsed = urlparse(link)
        # This public detail URL shape is indexed on Bamper. Extract titles only;
        # unavailable descriptions/finish must remain unknown.
        match = re.fullmatch(r"/zapchast_[^/]+/(\d+-[A-Za-z0-9_]+)[/]?", parsed.path)
        title = " ".join(" ".join(parts).split()) or title_attr
        if (parsed.scheme != "https" or parsed.hostname not in {"bamper.by", "www.bamper.by"}
                or parsed.query or not match or not title
                or not re.search(r"молдинг|накладк|molding", title, re.I)):
            continue
        items[match[1]] = Listing(source="bamper", id=match[1], title=title, url=link)
    if items:
        return list(items.values())
    if re.search(r"ничего не найдено|по вашему запросу[^<]{0,80}не найден", html, re.I):
        return []
    raise FetchError("Bamper: unsupported markup; public HTML could not be verified")


def scrape(client, url: str) -> list[Listing]:
    return parse_bamper(client.get(url), url)
