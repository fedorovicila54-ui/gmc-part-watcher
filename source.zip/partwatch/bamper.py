"""Read public Bamper listing cards without mixing neighboring descriptions.

Verified against the normal browser-visible DOM on 2026-10-20. The transport
must enforce robots.txt and stop at an unresolved security challenge.
"""
from __future__ import annotations

from decimal import Decimal, InvalidOperation
import re
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

from .http import FetchError
from .models import Listing


_DETAIL_PATH = re.compile(r"/zapchast_[^/]+/(\d+-[A-Za-z0-9_-]+)/?")
_PART_NAME = re.compile(r"молдинг|накладк|уголок|molding", re.I)


def _identity(href: str, base: str):
    url = urljoin(base, href)
    parsed = urlparse(url)
    match = _DETAIL_PATH.fullmatch(parsed.path)
    if (parsed.scheme != "https" or parsed.hostname not in {"bamper.by", "www.bamper.by"}
            or parsed.query or not match):
        return None
    return match[1], url


def _price(card) -> str:
    node = card.select_one("[data-price-byn]")
    if node is not None:
        try:
            # Bamper's public data-price-byn is already in major BYN units.
            return f"{Decimal(node['data-price-byn']).normalize():f} BYN"
        except (InvalidOperation, TypeError, ValueError):
            pass
    text = card.get_text(" ", strip=True)
    return "Договорная" if re.search(r"цена не указана|договорн", text, re.I) else ""


def parse_bamper(html: str, url: str) -> list[Listing]:
    soup = BeautifulSoup(html, "html.parser")
    items = {}
    for anchor in soup.select("a.ad-card-carousel-wrapper[href]"):
        identity = _identity(anchor["href"], url)
        title = " ".join(str(anchor.get("title") or "").split())
        if not identity or not _PART_NAME.search(title):
            continue
        # One direct parent is one actual card in the verified public markup.
        # Never expand to the results grid: that mixes color/OEM/price.
        card = anchor.parent
        description = "\n".join(filter(None, (
            p.get_text(" ", strip=True) for p in card.find_all("p")
        )))
        image = anchor.select_one('img[alt^="Bamper.by"][src]')
        image_url = urljoin(url, image["src"]) if image is not None else ""
        item_id, link = identity
        items[item_id] = Listing(source="bamper", id=item_id, title=title, url=link,
                                 description=description, price=_price(card), image_url=image_url)
    if items:
        return list(items.values())

    # Older layouts can still provide public detail links. These remain
    # unknown-finish candidates; do not read arbitrary ancestor descriptions.
    for anchor in soup.select("a[href]"):
        identity = _identity(anchor["href"], url)
        title = " ".join(str(anchor.get("title") or anchor.get_text(" ", strip=True)).split())
        if identity and _PART_NAME.search(title):
            item_id, link = identity
            items[item_id] = Listing(source="bamper", id=item_id, title=title, url=link)
    if items:
        return list(items.values())
    if re.search(r"ничего не найдено|по вашему запросу[^<]{0,80}не найден", html, re.I):
        return []
    raise FetchError("Bamper: unsupported markup; no public listing cards")


def scrape(client, url: str) -> list[Listing]:
    return parse_bamper(client.get(url), url)
