"""Render public pages in a fresh Chromium session; never click human checks."""
from __future__ import annotations

import time
import json
import os
import signal
import subprocess
import sys
from types import SimpleNamespace
from urllib.parse import urlsplit

from .http import FetchError, validate_url


class BrowserSession:
    def __init__(self, channel="chromium", headless=True, storage_state=None):
        self.channel = channel
        self.headless = headless
        self.runtime = None
        self.browser = None
        self.context = None
        self.blocked = {}
        self.storage_state = storage_state

    def _start(self):
        if self.context is not None:
            return
        try:
            from playwright.sync_api import sync_playwright
            self.runtime = sync_playwright().start()
            self.browser = self.runtime.chromium.launch(channel=self.channel, headless=self.headless)
            self.context = self.browser.new_context(locale="ru-RU", storage_state=self.storage_state)
        except Exception:
            self.close()
            raise FetchError("browser: Chromium недоступен; установите playwright install chromium") from None

    @staticmethod
    def _challenge(page):
        body = page.content().lower()
        title = page.title().lower()
        return ("safelinechallenge" in body or "slg-copyright" in body or "cf-chl-" in body
                or "just a moment" in title or "система безопасности" in title
                or "checking your browser" in title or "выполнение проверки безопасности" in body)

    def get(self, url):
        validate_url(url)
        host = urlsplit(url).hostname
        if host in self.blocked:
            raise FetchError(self.blocked[host])
        self._start()
        page = self.context.new_page()
        last_status = [None]

        def capture(response):
            if response.request.resource_type == "document" and response.frame == page.main_frame:
                last_status[0] = response.status

        def restrict(route):
            # Third-party page resources may render normally. Document redirects
            # must remain on the approved public marketplaces.
            request = route.request
            if request.is_navigation_request() and request.frame == page.main_frame:
                try:
                    validate_url(request.url)
                except FetchError:
                    route.abort()
                    return
            route.continue_()

        page.on("response", capture)
        page.route("**/*", restrict)
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=35000)
            deadline = time.monotonic() + 40
            while self._challenge(page) and time.monotonic() < deadline:
                # Allow the site's own automatic JavaScript loading to finish.
                # No checkbox, Confirm button, puzzle or CAPTCHA is clicked.
                page.wait_for_timeout(1000)
            if self._challenge(page):
                error = "interactive: сайт требует проверку человека в браузере; каталог не прочитан"
                self.blocked[host] = error
                raise FetchError(error)
            validate_url(page.url)
            text = page.locator("body").inner_text(timeout=5000) if urlsplit(url).path == "/robots.txt" else page.content()
            status = last_status[0] or 200
            return SimpleNamespace(status_code=status, text=text, content=text.encode("utf-8"),
                                   is_redirect=False, headers={}, apparent_encoding="utf-8", encoding="utf-8")
        except FetchError:
            raise
        except Exception:
            raise FetchError("browser: ошибка загрузки или таймаут публичной страницы") from None
        finally:
            page.close()

    def close(self):
        for resource in (self.context, self.browser):
            if resource is not None:
                try:
                    resource.close()
                except Exception:
                    pass
        if self.runtime is not None:
            try:
                self.runtime.stop()
            except Exception:
                pass
        self.context = self.browser = self.runtime = None


class BrowserTransport:
    """Bound even an unresponsive renderer; preserve only bot-owned memory."""
    def __init__(self, channel="chromium", headless=True, timeout=80):
        self.channel, self.headless, self.timeout = channel, headless, timeout
        self.storage_state = None
        self.blocked = {}

    @staticmethod
    def _stop(process):
        if process.poll() is not None:
            return
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
        else:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        process.communicate(timeout=10)

    def get(self, url):
        validate_url(url)
        host = urlsplit(url).hostname
        if host in self.blocked:
            raise FetchError(self.blocked[host])
        payload = {"url": url, "channel": self.channel, "headless": self.headless, "storage_state": self.storage_state}
        # Browser workers never need the Telegram/GitHub credentials of the job.
        env = {key: value for key, value in os.environ.items()
               if not any(word in key.upper() for word in ("TOKEN", "SECRET", "PASSWORD", "API_KEY"))}
        kwargs = {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}
        process = subprocess.Popen([sys.executable, "-m", "partwatch.browser_worker"],
                                   stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   text=True, encoding="utf-8", env=env, **kwargs)
        try:
            output, _ = process.communicate(json.dumps(payload), timeout=self.timeout)
        except subprocess.TimeoutExpired:
            self._stop(process)
            error = "browser: превышен лимит загрузки; проверка сайта не завершилась"
            self.blocked[host] = error
            raise FetchError(error) from None
        try:
            result = json.loads(output)
            if process.returncode != 0 or not isinstance(result, dict):
                raise ValueError()
            if result.get("error"):
                error = str(result["error"])[:300]
                if error.startswith("interactive:"):
                    self.blocked[host] = error
                raise FetchError(error)
            status, text = result["status"], result["text"]
            if not isinstance(status, int) or not isinstance(text, str) or len(text.encode("utf-8")) > 12_000_000:
                raise ValueError()
            self.storage_state = result.get("storage_state")
            return SimpleNamespace(status_code=status, text=text, content=text.encode("utf-8"),
                                   is_redirect=False, headers={}, apparent_encoding="utf-8", encoding="utf-8")
        except (ValueError, KeyError, TypeError):
            raise FetchError("browser: некорректный ответ изолированного браузера") from None

    def close(self):
        self.storage_state = None
        self.blocked.clear()
