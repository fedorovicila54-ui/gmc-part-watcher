from dataclasses import dataclass, field


@dataclass
class Listing:
    source: str
    id: str
    title: str
    url: str
    description: str = ""
    price: str = ""
    image_url: str = ""


@dataclass
class Decision:
    status: str
    reasons: list[str] = field(default_factory=list)
