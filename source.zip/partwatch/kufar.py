"""Kufar's public, server-rendered listing and detail JSON.

Use category URLs without query/cursor parameters; those parameters are
disallowed in auto.kufar.by/robots.txt. No private API is needed.
"""
from __future__ import annotations

from decimal import Decimal, InvalidOperation
from html.parser import HTMLParser
import json
import logging
import re
from urllib.parse import urlparse

from .http import FetchError
from .models import Listing

LOG = logging.getLogger(__name__)
DETAIL_LIMIT = 20


class _NextData(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.reading = False
        self.parts: list[str] = []

    def handle_starttag(self, tag, attrs):
        if tag == "script" and dict(attrs).get("id") == "__NEXT_DATA__":
            self.reading = True

    def handle_endtag(self, tag):
        if tag == "script":
            self.reading = False

    def handle_data(self, data):
        if self.reading:
            self.parts.append(data)


def _state(html: str) -> dict:
    parser = _NextData()
    parser.feed(html)
    try:
        return json.loads("".join(parser.parts))["props"]["initialState"]
    except (ValueError, KeyError, TypeError) as exc:
        raise FetchError("Kufar: unsupported markup (missing valid __NEXT_DATA__)" ) from exc


def _params_text(params) -> str:
    if isinstance(params, dict):
        params = params.values()
    lines = []
    for param in params or []:
        if not isinstance(param, dict):
            continue
        key = param.get("p", "")
        # Keep only part/vehicle fields. Seller and account fields are unnecessary.
        if not (key.startswith("spares_") or key.startswith("cars_")):
            continue
        value = param.get("vl") or param.get("v") or ""
        if isinstance(value, list):
            value = ", ".join(map(str, value))
        lines.append(f"{param.get('pl') or key} ({key}): {value}")
    return "\n".join(lines)


def _price(ad: dict) -> str:
    # Raw Kufar amounts are minor units, including price_byn and calculator.price.
    amount = ad.get("price_byn")
    if amount is None:
        amount = next((p.get("price") for p in ad.get("calculator", [])
                       if p.get("currency") == "BYN"), None)
    try:
        price = Decimal(str(amount)) / 100
        return f"{price.normalize():f} BYN" if price > 0 else "Договорная"
    except (InvalidOperation, TypeError, ValueError):
        return str(ad.get("price") or "")


def _allowed_url(url: str) -> bool:
    parsed = urlparse(url)
    return (parsed.scheme == "https" and parsed.hostname == "auto.kufar.by"
            and bool(re.fullmatch(r"/vi/\d+/?", parsed.path))
            and not parsed.query)


def _image(ad: dict) -> str:
    images = ad.get("images") or []
    if isinstance(images, dict):
        galleries = images.get("gallery") or images.get("listings") or []
        return str(galleries[0]) if galleries else str(ad.get("image") or "")
    if images and isinstance(images[0], dict):
        path = images[0].get("path", "")
        # This exact image URL form is present in the public detail HTML.
        if path.startswith("adim") and not any(c in path for c in "?#"):
            return "https://rms.kufar.by/v1/gallery/" + path
    return ""


def _listing(ad: dict, detail: bool = False) -> Listing | None:
    ad_id = str(ad.get("adId") or ad.get("ad_id") or ad.get("id") or "")
    url = str(ad.get("adViewLink") or ad.get("ad_link") or "")
    if not ad_id or not _allowed_url(url):
        return None
    title = str(ad.get("title") or ad.get("subject") or "")
    params = ad.get("adParams") if detail else ad.get("ad_parameters")
    description = "\n".join(filter(None, [
        str(ad.get("body") or ad.get("description") or ad.get("body_short") or ""),
        _params_text(params),
    ]))
    return Listing(source="kufar", id=ad_id, title=title, url=url,
                   description=description, price=_price(ad), image_url=_image(ad))


def parse_kufar(html: str, url: str) -> list[Listing]:
    state = _state(html)
    if re.fullmatch(r"/vi/\d+/?", urlparse(url).path):
        detail = (state.get("adView") or {}).get("data")
        if not isinstance(detail, dict) or not detail.get("adId"):
            raise FetchError("Kufar: unsupported detail markup")
        item = _listing(detail, detail=True)
        return [item] if item else []
    listing = state.get("listing")
    if not isinstance(listing, dict) or not isinstance(listing.get("ads"), list):
        raise FetchError("Kufar: unsupported listing markup")
    items = [_listing(ad) for ad in listing["ads"] if isinstance(ad, dict)]
    return [item for item in items if item is not None]


def _needs_detail(item: Listing) -> bool:
    text = (item.title + "\n" + item.description).lower()
    return ("terrain" in text and bool(re.search(r"молдинг|накладк|арки|арка", text))
            and bool(re.search(r"лев|\bleft\b|\blh\b", text))
            and bool(re.search(r"перед|\bfront\b|\blf\b", text))
            and not re.search(r"terrain\s*(?:iii|3)\b|\b20(?:2[5-9]|[3-9]\d)\s*г", text))


def scrape(client, url: str) -> list[Listing]:
    items = parse_kufar(client.get(url), url)
    if re.fullmatch(r"/vi/\d+/?", urlparse(url).path):
        return items
    fetched = 0
    for index, item in enumerate(items):
        if fetched >= DETAIL_LIMIT or not _needs_detail(item):
            continue
        fetched += 1
        try:
            detail = parse_kufar(client.get(item.url), item.url)
        except FetchError as exc:
            # Preserve the candidate as unknown color, while making failures visible.
            LOG.warning("Kufar detail unavailable %s: %s", item.url, exc)
            continue
        if detail:
            full = detail[0]
            items[index] = Listing(
                source=item.source, id=item.id, title=full.title or item.title,
                url=item.url,
                description="\n".join(filter(None, [item.description, full.description])),
                price=full.price or item.price, image_url=full.image_url or item.image_url,
            )
    return items
