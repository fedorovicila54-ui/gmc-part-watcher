"""Conservative, explainable matching for the requested Terrain fender trim.

Only text explicitly describing the part can confirm its finish. A donor car's
colour, a missing chrome finish, and a photo are not proof of black trim.
"""

from __future__ import annotations

import re
import unicodedata

from .models import Decision, Listing


REFERENCE_ID = "138518208"
_TERRAIN = re.compile(r"\b(?:terrain|террейн|терреин)\b")
_TRIM = re.compile(r"\b(?:молдинг\w*|накладк\w*|расширител\w*|moulding|molding|trim|flare)\b")
_PANEL = re.compile(r"\b(?:крыл\w*|арк\w*|fender|wheel\s+arch)\b")
_FRONT = re.compile(r"\b(?:передн\w*|front)\b")
_LEFT = re.compile(r"\b(?:лев(?:ый|ая|ое|ого|ой|ую|ом|ые|ых)?|left|lh|lhs)\b")
_RIGHT = re.compile(r"\b(?:прав(?:ый|ая|ое|ого|ой|ую|ом|ые|ых)?|right|rh|rhs)\b")
_REAR = re.compile(r"\b(?:задн\w*|rear|back)\b")
_BLACK = re.compile(r"\b(?:черн(?:ый|ая|ое|ого|ой|ую|ом|ые|ых|ыми|ым)|black)\b")
_CHROME = re.compile(r"\b(?:хром\w*|chrom(?:e|ed|ium))\b")
_DONOR = re.compile(
    r"\b(?:автомобил\w*|машин\w*|донор\w*|кузов\w*|car|vehicle|donor|body\s+colou?r)\b"
)
_YEARS = re.compile(r"\b(?:19[89]\d|20[0-3]\d)\b")
_GEN_ONE = re.compile(
    r"\b(?:terrain|террейн|терреин)\s*[-:/]?\s*(?:i|1)\b"
    r"|\b(?:перв\w*|1|i)[ -]*(?:поколени\w*|generation|gen)\b"
)
_GEN_TWO = re.compile(
    r"\b(?:terrain|террейн|терреин)\s*[-:/]?\s*(?:ii|2)\b"
    r"|\b(?:втор\w*|2|ii)[ -]*(?:поколени\w*|generation|gen)\b"
)
_GEN_THREE = re.compile(
    r"\b(?:terrain|террейн|терреин)\s*[-:/]?\s*(?:iii|3)\b"
    r"|\b(?:трет\w*|3|iii)[ -]*(?:поколени\w*|generation|gen)\b"
)
_REAR_FENDER = re.compile(
    r"\bзадн\w*\s+(?:(?:лев\w*|прав\w*)\s+)?(?:крыл\w*|арк\w*)\b"
    r"|\b(?:крыл\w*|арк\w*)\s+задн\w*\b"
    r"|\brear\s+(?:(?:left|right|lh|rh)\s+)?(?:fender|wheel\s+arch)\b"
    r"|\b(?:fender|wheel\s+arch)\s+rear\b"
)
_OTHER_FINISH = re.compile(
    r"\b(?:бел\w*|серебрист\w*|красн\w*|син(?:ий|яя|ее|его|ей|юю)|white|silver|red|blue)\b"
)
_ARCH = re.compile(r"\b(?:арк\w*|расширител\w*|arch|flare)\b")
_ASSEMBLY = re.compile(r"\b(?:в\s+сборе|целиком|полност\w*|полная|полный|вся|весь|complete|assembly|whole)\b")


def _normalise(value: str) -> str:
    return unicodedata.normalize("NFKC", str(value or "")).lower().replace("ё", "е").replace("–", "-").replace("—", "-")


def _clauses(text: str) -> list[str]:
    return [part.strip() for part in re.split(r"[.!?;\n]+", text) if part.strip()]


def _negated(text: str, start: int, end: int) -> bool:
    before = text[max(0, start - 45):start]
    after = text[end:end + 35]
    return bool(
        re.search(r"\b(?:не|нет|без|not|no|without|non|anti)[ -]*(?:\w+[ -]+){0,1}$", before)
        or re.match(r"\s*(?:отсутству\w*|нет\b|не\s+(?:имеется|установлен\w*)|absent\b)", after)
    )


def _affirmative(pattern: re.Pattern[str], text: str) -> bool:
    return any(not _negated(text, match.start(), match.end()) for match in pattern.finditer(text))


def _part_clauses(title: str, description: str) -> list[str]:
    # A steering-wheel orientation says nothing about the fender's side.
    clean = re.sub(r"\b(?:лев\w*|прав\w*)\s+рул\w*\b", "", title + ". " + description)
    return [clause for clause in _clauses(clean) if _TRIM.search(clause) and _PANEL.search(clause)]


def _explicit_part_colour(pattern: re.Pattern[str], title: str, description: str) -> bool:
    for clause in _clauses(title) + _clauses(description):
        # Marketplace 'colour' fields often describe the donor. Require ownership.
        for field in re.split(r",", clause):
            if re.search(r"\b(?:цвет|colou?r|отделка|finish)\s+(?:самой\s+)?(?:детал\w*|молдинг\w*|накладк\w*|расширител\w*|trim|part)\b", field):
                if _affirmative(pattern, field):
                    return True
        if _DONOR.search(clause):
            continue
        for noun in _TRIM.finditer(clause):
            for colour in pattern.finditer(clause):
                if _negated(clause, colour.start(), colour.end()):
                    continue
                gap = clause[min(noun.end(), colour.end()):max(noun.start(), colour.start())]
                if len(re.findall(r"\b\w+\b", gap)) <= 8:
                    return True
    return False


def _fitment_years(title: str, description: str) -> list[int]:
    relevant = [title]
    relevant.extend(
        clause for clause in _clauses(description)
        if _TERRAIN.search(clause)
        or re.search(r"\b(?:год\w*|совместим\w*|подходит|fitment|model\s+year)\b", clause)
    )
    return [int(match.group()) for text in relevant for match in _YEARS.finditer(text)]


def _oem_match(text: str, numbers: list[str]) -> bool:
    # OEM numbers are supplied by the operator only after verification. Never
    # infer one from other trim listings or a similar-looking photograph.
    for number in numbers:
        compact = re.sub(r"[^a-z0-9]", "", _normalise(number))
        if not compact:
            continue
        expression = r"(?<![a-z0-9])" + r"[\s-]*".join(map(re.escape, compact)) + r"(?![a-z0-9])"
        if re.search(expression, text):
            return True
    return False


def _whole_arch(text: str, part_clauses: list[str]) -> bool:
    # This number identifies the full arch piece in the researched reference
    # material. It is NOT an approved black insert/finish identifier.
    return _oem_match(text, ["84579557"]) or any(
        _ARCH.search(clause) and _ASSEMBLY.search(clause) for clause in part_clauses
    )


def classify(listing: Listing, config: dict) -> Decision:
    """Return ``black``, ``review`` or ``reject`` with human-readable reasons.

    ``notify_review`` controls delivery elsewhere; it intentionally does not
    alter the classification. Unknown generation/finish stays reviewable.
    """
    title = _normalise(listing.title)
    description = _normalise(listing.description)
    text = title + ". " + description
    excluded = {REFERENCE_ID, *(str(value) for value in config.get("excluded_ids", []))}
    if str(listing.id) in excluded or any(re.search(r"(?<!\d)" + re.escape(value) + r"(?!\d)", listing.url) for value in excluded if value):
        return Decision("reject", ["Исключенное объявление, включая исходный хромированный образец."])

    if not _TERRAIN.search(text):
        return Decision("reject", ["Не подтверждена модель GMC Terrain."])
    if _affirmative(_GEN_ONE, text):
        return Decision("reject", ["Указано первое поколение Terrain; требуется Terrain II."])
    if _affirmative(_GEN_THREE, text):
        return Decision("reject", ["Указано третье поколение Terrain; требуется Terrain II."])

    parts = _part_clauses(title, description)
    if not parts:
        return Decision("reject", ["Не подтвержден молдинг, накладка или расширитель крыла/арки."])
    part_text = ". ".join(parts)
    if _affirmative(_RIGHT, part_text):
        return Decision("reject", ["У детали указана правая сторона."])
    front_position = _affirmative(_FRONT, part_text)
    if _affirmative(_REAR_FENDER, part_text) or (_affirmative(_REAR, part_text) and not front_position):
        return Decision("reject", ["Указана деталь заднего крыла/арки."])
    if not front_position or not _affirmative(_LEFT, part_text):
        return Decision("reject", ["Не подтверждены переднее крыло и левая сторона детали."])

    minimum, maximum = int(config.get("year_min", 2017)), int(config.get("year_max", 2022))
    years = _fitment_years(title, description)
    if years and (max(years) < minimum or min(years) > maximum):
        return Decision("reject", [f"Указанные годы не входят в диапазон {minimum}-{maximum}."])

    # Chrome is checked across the listing: many sellers put the finish only
    # in the description. Explicit negations are not evidence of chrome.
    if _affirmative(_CHROME, text):
        return Decision("reject", ["В тексте явно указан хром/хромированная отделка."])
    if _explicit_part_colour(_OTHER_FINISH, title, description):
        return Decision("reject", ["У самой детали явно указан другой цвет."])

    reasons = ["Совпадают Terrain и молдинг/накладка переднего левого крыла/арки."]
    if _whole_arch(text, parts):
        reasons.append("Указана накладка арки целиком/в сборе; соответствие отдельному молдингу требует проверки.")
        return Decision("review", reasons)
    generation_known = _affirmative(_GEN_TWO, text) or bool(years and all(minimum <= year <= maximum for year in years))
    black = _explicit_part_colour(_BLACK, title, description)
    known_oem = _oem_match(text, list(config.get("black_oem_numbers", [])))
    if generation_known and (black or known_oem):
        reasons.append("Черная отделка самой детали явно указана." if black else "Совпадает проверенный OEM черной детали из настроек.")
        return Decision("black", reasons)
    if not generation_known:
        reasons.append("Поколение II или точный подходящий год требуют проверки.")
    if not black and not known_oem:
        reasons.append("Черный цвет самой детали не подтвержден; цвет донора и отсутствие хрома недостаточны.")
    return Decision("review", reasons)
