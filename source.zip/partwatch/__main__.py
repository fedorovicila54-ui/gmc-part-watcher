import argparse
from dataclasses import asdict, replace
from datetime import datetime, timezone
import html
import json
import os
from pathlib import Path
import sys

from .http import Client, FetchError
from .matching import classify
from .telegram import Telegram, TelegramError


def coalesce_listings(listings):
    """Keep all evidence when the same advert appears in several categories."""
    unique = {}
    for item in listings:
        key = (item.source, item.id)
        previous = unique.get(key)
        if previous is None:
            unique[key] = item
            continue
        evidence = list(dict.fromkeys(filter(None, (previous.title, item.title, previous.description, item.description))))
        unique[key] = replace(previous, title=max((previous.title, item.title), key=len),
                              description="\n".join(evidence), price=item.price or previous.price,
                              image_url=item.image_url or previous.image_url)
    return list(unique.values())


def make_client(config):
    headless = os.getenv("GMC_BROWSER_HEADLESS", str(config.get("browser_headless", True))).lower() not in ("false", "0", "no")
    return Client(config.get("request_interval_seconds", 3), config.get("browser_hosts"),
                  config.get("browser_channel", "chromium"), headless)


def read_state(path):
    if not path.exists():
        return {"version": 1, "sent": {}, "health": {}}
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or value.get("version") != 1 or not isinstance(value.get("sent"), dict) or not isinstance(value.get("health"), dict):
        raise ValueError("Некорректный формат state.json; остановка во избежание повторных рассылок")
    return value


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temp, path)


def run(config, state_path, report_path, notify=False, client=None, telegram=None):
    from . import kufar, bamper, avby
    adapters = {"kufar": kufar, "bamper": bamper, "avby": avby}
    state = read_state(state_path)
    client = client or make_client(config)
    bot = (telegram or Telegram()) if notify else None
    now = datetime.now(timezone.utc).isoformat()
    report = {"checked_at": now, "mode": "notify" if notify else "dry-run", "sources": [], "candidates": [], "sent": 0}
    failures = 0
    seen = set()
    for source in config["sources"]:
        if not source.get("enabled", True):
            continue
        name = source["name"]
        urls = list(dict.fromkeys(source.get("urls") or [source["url"]]))
        listings = []
        checks = []
        for url in urls:
            try:
                found = adapters[name].scrape(client, url)
                listings.extend(found)
                checks.append({"url": url, "status": "ok", "count": len(found)})
            except (FetchError, ValueError, KeyError) as exc:
                checks.append({"url": url, "status": "unavailable", "error": str(exc)[:300]})
        successful = sum(check["status"] == "ok" for check in checks)
        listings = coalesce_listings(listings)
        if successful == len(checks):
            status = {"name": name, "status": "ok", "count": len({item.id for item in listings}), "note": "Проверены первые страницы настроенных категорий", "checks": checks}
        else:
            failures += 1
            status = {"name": name, "status": "partial" if successful else "unavailable", "error": "; ".join(dict.fromkeys(check["error"] for check in checks if check["status"] != "ok"))[:300], "checks": checks}
            if successful:
                status["count"] = len({item.id for item in listings})
        report["sources"].append(status)
        health_key = status["status"] + ":" + status.get("error", "")
        if bot and state["health"].get(name) != health_key:
            message = (f"⚠️ {name}: " + ("часть категорий недоступна. " if successful else "поиск недоступен. ") + status["error"]) if status["status"] != "ok" else f"✅ {name}: чтение работает, объявлений: {status['count']}."
            bot.send(html.escape(message))
            state["health"][name] = health_key
            write_json(state_path, state)
        for listing in listings:
            key = f"{listing.source}:{listing.id}"
            if key in seen:
                continue
            seen.add(key)
            decision = classify(listing, config)
            if decision.status == "reject":
                continue
            report["candidates"].append({**asdict(listing), **asdict(decision)})
    report["candidates"].sort(key=lambda item: item["status"] != "black")
    for item in report["candidates"]:
        if item["status"] == "review" and not config.get("notify_review", True):
            continue
        key = f"{item['source']}:{item['id']}:{item['status']}"
        if bot and key not in state["sent"] and report["sent"] < config.get("max_notifications", 10):
            from .models import Listing, Decision
            bot.send_listing(Listing(**{k: item[k] for k in Listing.__dataclass_fields__}), Decision(item["status"], item["reasons"]))
            state["sent"][key] = now
            write_json(state_path, state)
            report["sent"] += 1
    # A dry run must not mark candidates or health notifications as sent.
    if bot:
        state["last_run"] = now
        write_json(state_path, state)
    write_json(report_path, report)
    print(json.dumps({"sources": report["sources"], "candidates": len(report["candidates"]), "sent": report["sent"]}, ensure_ascii=False))
    return 2 if failures else 0


def main():
    parser = argparse.ArgumentParser(description="GMC Terrain: молдинг переднего левого крыла без хрома")
    parser.add_argument("--config", type=Path, default=Path("config.json"))
    parser.add_argument("--state", type=Path, default=Path(".state/state.json"))
    parser.add_argument("--report", type=Path, default=Path("report.json"))
    parser.add_argument("--notify", action="store_true", help="Отправить новые совпадения в Telegram")
    args = parser.parse_args()
    try:
        config = json.loads(args.config.read_text(encoding="utf-8"))
        client = make_client(config)
        try:
            return run(config, args.state, args.report, args.notify, client=client)
        finally:
            client.close()
    except (OSError, ValueError, TelegramError) as exc:
        print(f"Ошибка: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
