"""Telegram token is never included in errors or application logs."""
import html
import os
import re

import requests


class TelegramError(Exception):
    pass


class Telegram:
    def __init__(self, token=None, chat_id=None):
        self.token = str(token or os.getenv("TELEGRAM_BOT_TOKEN", "")).strip()
        self.chat_id = str(chat_id or os.getenv("TELEGRAM_CHAT_ID", "")).strip()
        if not re.fullmatch(r"\d+:[A-Za-z0-9_-]+", self.token) or not self.chat_id:
            raise TelegramError("Задайте TELEGRAM_BOT_TOKEN и TELEGRAM_CHAT_ID в Secrets/окружении")
        if not re.fullmatch(r"-?\d+", self.chat_id):
            raise TelegramError("TELEGRAM_CHAT_ID должен содержать только числовой ID вашего чата")

    def call(self, method, payload):
        try:
            response = requests.post(f"https://api.telegram.org/bot{self.token}/{method}", json=payload, timeout=25)
            data = response.json()
        except (requests.RequestException, ValueError):
            raise TelegramError("Telegram: ошибка соединения или некорректный ответ") from None
        if not isinstance(data, dict):
            raise TelegramError("Telegram: некорректный формат ответа")
        if response.status_code != 200 or data.get("ok") is not True:
            # Never echo request URLs, exception strings or the token.
            code = data.get("error_code")
            code = code if isinstance(code, int) else response.status_code
            reasons = {
                "Bad Request: chat not found": "чат не найден; проверьте числовой TELEGRAM_CHAT_ID и нажмите Start у бота",
                "Forbidden: bot was blocked by the user": "бот заблокирован пользователем",
                "Forbidden: bot can't initiate conversation with a user": "сначала нажмите Start у бота",
            }
            reason = reasons.get(str(data.get("description")), "")
            raise TelegramError(f"Telegram API: ошибка {code}" + (f" — {reason}" if reason else ""))
        return data.get("result")

    def send(self, text):
        self.call("sendMessage", {"chat_id": self.chat_id, "text": text, "parse_mode": "HTML", "link_preview_options": {"is_disabled": False}})

    def send_listing(self, listing, decision):
        heading = "⚫ Указана черная отделка" if decision.status == "black" else "🔎 Кандидат — проверьте цвет и форму"
        # Bound raw fields before escaping; slicing HTML can cut an entity/tag.
        lines = [heading, html.escape(listing.title[:300]), html.escape((listing.price or "Цена не указана")[:80]),
                 html.escape("; ".join(decision.reasons)[:600]),
                 f'<a href="{html.escape(listing.url, quote=True)}">Открыть на {html.escape(listing.source)}</a>',
                 "Сверьте фото, крепления и совместимость с вашей машиной."]
        self.send("\n".join(lines))
