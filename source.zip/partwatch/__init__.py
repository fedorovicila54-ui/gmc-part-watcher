"""Low-volume GMC Terrain part monitor."""
