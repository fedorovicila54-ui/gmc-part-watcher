"""Private worker for browser_http; JSON via pipes, no credentials or profile."""
import json
import sys

from .browser_http import BrowserSession
from .http import FetchError


def main():
    session = None
    try:
        value = json.load(sys.stdin)
        session = BrowserSession(value.get("channel", "chromium"), value.get("headless", True), value.get("storage_state"))
        response = session.get(value["url"])
        result = {"status": response.status_code, "text": response.text, "storage_state": session.context.storage_state()}
    except FetchError as error:
        result = {"error": str(error)}
    except Exception:
        result = {"error": "browser: ошибка изолированного браузера"}
    finally:
        if session is not None:
            session.close()
    print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
