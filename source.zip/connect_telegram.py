"""Run locally after pressing Start in the bot; token stays in environment."""
import os
import requests
from partwatch.telegram import Telegram, TelegramError

if __name__ == "__main__":
    try:
        bot = Telegram(chat_id="discover-only")
        updates = bot.call("getUpdates", {"timeout": 0, "allowed_updates": ["message"]})
        chats = sorted({str(update["message"]["chat"]["id"]) for update in updates or []
                        if "message" in update and update["message"]["chat"].get("type") == "private"})
        if chats:
            print("Private chat ID (выберите свой): " + ", ".join(chats))
        else:
            print("Нажмите Start в @GMC12213_bot, затем запустите еще раз.")
    except TelegramError as exc:
        print(exc)
