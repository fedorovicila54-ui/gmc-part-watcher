"""Rebuild the deployable source archive without runtime data or secrets."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent
paths = [root / name for name in ("README.md", "requirements.txt", "config.json", "connect_telegram.py", "pack.py", ".gitignore")]
for folder in ("partwatch", "tests", ".github"):
    paths.extend(p for p in (root / folder).rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc")
with ZipFile(root / "source.zip", "w", ZIP_DEFLATED) as archive:
    for path in sorted(paths):
        archive.write(path, path.relative_to(root).as_posix())
print(f"source.zip: {len(paths)} files")
